﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double num1, num2, result;

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNum2, "");
                num2 = Convert.ToDouble(txtNum2.Text);
            }
            catch(Exception)
            {
                errorProvider2.SetError(txtNum2, "Número inválido");
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out num1) || (!Double.TryParse(txtNum2.Text, out num2)))
            {
                txtNum1.Focus();
            }
            else
            {
                result = num1 + num2;
                txtResult.Text = result.ToString();
            }
         }

        private void btnSubt_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out num1) || (!Double.TryParse(txtNum2.Text, out num2)))
            {
                txtNum1.Focus();
            }
            else
            {
                result = num1 - num2;
                txtResult.Text = result.ToString();
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out num1) || (!Double.TryParse(txtNum2.Text, out num2)))
            {
                txtNum1.Focus();
            }
            else
            {
                result = num1 * num2;
                txtResult.Text = result.ToString();
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out num1) || (!Double.TryParse(txtNum2.Text, out num2)))
            {
                txtNum1.Focus();
            }
            else
            {
                if (num2 == 0)
                {
                    errorProvider2.SetError(txtNum2, "Número Inválido");
                }
                else
                {
                    result = num1 / num2;
                    txtResult.Text = result.ToString();
                }
            }
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResult.Clear();
        }

        private void btnSai_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Você deseja sair?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out num1))
            {
                errorProvider1.SetError(txtNum1, "Número inválido");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
