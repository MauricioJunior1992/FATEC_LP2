﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pnotebook02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            Double[,] vetPrecos = new double[2, 3];
            Double[] mediaNote = new double[2] { 0, 0 };
            double mediaGeral = 0;
            string valNote;
            int i, j;

            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    valNote = Interaction.InputBox($"Informe o valor do Notebook {i + 1} na loja {j + 1}");

                    if (!Double.TryParse(valNote, out vetPrecos[i, j]) ||
                         vetPrecos[i, j] < 0)
                    {
                        MessageBox.Show("Valor inválido. Digite novamente");
                        j--;
                    }
                    else
                    {
                        mediaNote[i] += vetPrecos[i, j];
                    }
                }
                mediaGeral += mediaNote[i];
            }
            mediaGeral /= 6;

            for (i = 0; i < 2; i++)
            {
                j = 0;
                lstbxNotebooks.Items.Add($"Notebook {i + 1} Loja {j + 1}: R${vetPrecos[i, j].ToString("N2")}   Loja {j + 2}: R${vetPrecos[i, j + 1].ToString("N2")} Loja {j + 3}: R${vetPrecos[i, j + 2].ToString("N2")} Média: R$ {(mediaNote[i] / 3).ToString("N2")} \n");
            }
            lstbxNotebooks.Items.Add("-----------------------------------------");
            lstbxNotebooks.Items.Add($"\n\nMédia Geral Computadores: R${mediaGeral.ToString("N2")}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxNotebooks.Items.Clear();
        }
    }
}
