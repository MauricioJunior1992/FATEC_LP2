﻿namespace PContato0030482413019
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.lblParticipantes = new System.Windows.Forms.Label();
            this.lblMauricio = new System.Windows.Forms.Label();
            this.lblRAMauricio = new System.Windows.Forms.Label();
            this.lblMiguel = new System.Windows.Forms.Label();
            this.lblRAMiguel = new System.Windows.Forms.Label();
            this.lblProjeto = new System.Windows.Forms.Label();
            this.lblAno2024 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblParticipantes
            // 
            this.lblParticipantes.AutoSize = true;
            this.lblParticipantes.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParticipantes.Location = new System.Drawing.Point(304, 85);
            this.lblParticipantes.Name = "lblParticipantes";
            this.lblParticipantes.Size = new System.Drawing.Size(116, 20);
            this.lblParticipantes.TabIndex = 0;
            this.lblParticipantes.Text = "Participantes";
            // 
            // lblMauricio
            // 
            this.lblMauricio.AutoSize = true;
            this.lblMauricio.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMauricio.Location = new System.Drawing.Point(249, 128);
            this.lblMauricio.Name = "lblMauricio";
            this.lblMauricio.Size = new System.Drawing.Size(238, 19);
            this.lblMauricio.TabIndex = 1;
            this.lblMauricio.Text = "Mauricio de Almeida Machado Junior";
            // 
            // lblRAMauricio
            // 
            this.lblRAMauricio.AutoSize = true;
            this.lblRAMauricio.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRAMauricio.Location = new System.Drawing.Point(293, 147);
            this.lblRAMauricio.Name = "lblRAMauricio";
            this.lblRAMauricio.Size = new System.Drawing.Size(137, 19);
            this.lblRAMauricio.TabIndex = 2;
            this.lblRAMauricio.Text = "RA: 0030482413019";
            // 
            // lblMiguel
            // 
            this.lblMiguel.AutoSize = true;
            this.lblMiguel.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiguel.Location = new System.Drawing.Point(271, 188);
            this.lblMiguel.Name = "lblMiguel";
            this.lblMiguel.Size = new System.Drawing.Size(191, 19);
            this.lblMiguel.TabIndex = 3;
            this.lblMiguel.Text = "MIguel Oliveira Rocha RIbeiro";
            // 
            // lblRAMiguel
            // 
            this.lblRAMiguel.AutoSize = true;
            this.lblRAMiguel.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRAMiguel.Location = new System.Drawing.Point(295, 207);
            this.lblRAMiguel.Name = "lblRAMiguel";
            this.lblRAMiguel.Size = new System.Drawing.Size(137, 19);
            this.lblRAMiguel.TabIndex = 4;
            this.lblRAMiguel.Text = "RA: 0030482413015";
            // 
            // lblProjeto
            // 
            this.lblProjeto.AutoSize = true;
            this.lblProjeto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjeto.Location = new System.Drawing.Point(280, 32);
            this.lblProjeto.Name = "lblProjeto";
            this.lblProjeto.Size = new System.Drawing.Size(152, 24);
            this.lblProjeto.TabIndex = 5;
            this.lblProjeto.Text = "PROJETO LP II";
            // 
            // lblAno2024
            // 
            this.lblAno2024.AutoSize = true;
            this.lblAno2024.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAno2024.Location = new System.Drawing.Point(305, 267);
            this.lblAno2024.Name = "lblAno2024";
            this.lblAno2024.Size = new System.Drawing.Size(102, 18);
            this.lblAno2024.TabIndex = 6;
            this.lblAno2024.Text = "ADS 1º/2024";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(21, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(190, 185);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(529, 128);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(214, 221);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblAno2024);
            this.Controls.Add(this.lblProjeto);
            this.Controls.Add(this.lblRAMiguel);
            this.Controls.Add(this.lblMiguel);
            this.Controls.Add(this.lblRAMauricio);
            this.Controls.Add(this.lblMauricio);
            this.Controls.Add(this.lblParticipantes);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblParticipantes;
        private System.Windows.Forms.Label lblMauricio;
        private System.Windows.Forms.Label lblRAMauricio;
        private System.Windows.Forms.Label lblMiguel;
        private System.Windows.Forms.Label lblRAMiguel;
        private System.Windows.Forms.Label lblProjeto;
        private System.Windows.Forms.Label lblAno2024;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}