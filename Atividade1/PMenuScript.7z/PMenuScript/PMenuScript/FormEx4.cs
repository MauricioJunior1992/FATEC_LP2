﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenuScript
{
    public partial class FormEx4 : Form
    {
        public FormEx4()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;

            foreach (char letra in rchTxtFrase.Text)
            {
                contaLetra++;
            }

            MessageBox.Show($"A quantidade de letras é: {contaLetra}");
        }

        private void btnContaNum_Click(object sender, EventArgs e)
        {
            int tamanho = rchTxtFrase.Text.Length;
            int i = 0;
            int contaNum = 0;

            while (i<tamanho)
            {
                if (char.IsNumber(rchTxtFrase.Text[i]))
                {
                    contaNum++;
                }
                i++;
            }
            MessageBox.Show($"A frase tem {contaNum} algarismos numéricos.");
        }

        private void btnEspBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            for (int i = 0;i < rchTxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchTxtFrase.Text[i]))
                {
                    posicao = i+1;
                    break;
                }
            }
            MessageBox.Show($"A posição do primeiro espaço em branco é {posicao}.");
        }
    }
}
