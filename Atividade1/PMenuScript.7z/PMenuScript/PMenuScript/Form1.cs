﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenuScript
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void menuScriptEx4_Click(object sender, EventArgs e)
        {

        }

        private void menuStripEx3_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx3>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["FormEx3"].BringToFront();
            }
            else
            {
                FormEx3 obj1 = new FormEx3();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void menuStripEx2_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx2>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["FormEx2"].BringToFront();
            }
            else
            {
                FormEx2 obj1 = new FormEx2();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void menuStripEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["FormEx5"].BringToFront();
            }
            else
            {
                FormEx5 obj1 = new FormEx5();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void menuStripEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["FormEx4"].BringToFront();
            }
            else
            {
                FormEx4 obj1 = new FormEx4();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }
    }
}
