﻿namespace PMenuScript
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStripEx2 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripEx3 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripEx4 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripEx5 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripSair = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuStripEx2,
            this.menuStripEx3,
            this.menuStripEx4,
            this.menuStripEx5,
            this.menuStripSair});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStripEx2
            // 
            this.menuStripEx2.Name = "menuStripEx2";
            this.menuStripEx2.Size = new System.Drawing.Size(75, 20);
            this.menuStripEx2.Text = "Exercício 2";
            this.menuStripEx2.Click += new System.EventHandler(this.menuStripEx2_Click);
            // 
            // menuStripEx3
            // 
            this.menuStripEx3.Name = "menuStripEx3";
            this.menuStripEx3.Size = new System.Drawing.Size(75, 20);
            this.menuStripEx3.Text = "Exercício 3";
            this.menuStripEx3.Click += new System.EventHandler(this.menuStripEx3_Click);
            // 
            // menuStripEx4
            // 
            this.menuStripEx4.Name = "menuStripEx4";
            this.menuStripEx4.Size = new System.Drawing.Size(75, 20);
            this.menuStripEx4.Text = "Exercício 4";
            this.menuStripEx4.Click += new System.EventHandler(this.menuStripEx4_Click);
            // 
            // menuStripEx5
            // 
            this.menuStripEx5.Name = "menuStripEx5";
            this.menuStripEx5.Size = new System.Drawing.Size(75, 20);
            this.menuStripEx5.Text = "Exercício 5";
            this.menuStripEx5.Click += new System.EventHandler(this.menuStripEx5_Click);
            // 
            // menuStripSair
            // 
            this.menuStripSair.Name = "menuStripSair";
            this.menuStripSair.Size = new System.Drawing.Size(38, 20);
            this.menuStripSair.Text = "Sair";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuStripEx2;
        private System.Windows.Forms.ToolStripMenuItem menuStripEx3;
        private System.Windows.Forms.ToolStripMenuItem menuStripEx4;
        private System.Windows.Forms.ToolStripMenuItem menuStripEx5;
        private System.Windows.Forms.ToolStripMenuItem menuStripSair;
    }
}

