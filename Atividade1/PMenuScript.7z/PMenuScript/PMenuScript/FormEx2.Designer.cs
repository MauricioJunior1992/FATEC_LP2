﻿namespace PMenuScript
{
    partial class FormEx2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.lblPalvara1 = new System.Windows.Forms.Label();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.btnComparar = new System.Windows.Forms.Button();
            this.btnInserir = new System.Windows.Forms.Button();
            this.btnAsteriscos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(255, 61);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(100, 20);
            this.txtPalavra1.TabIndex = 0;
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(255, 100);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(100, 20);
            this.txtPalavra2.TabIndex = 1;
            // 
            // lblPalvara1
            // 
            this.lblPalvara1.AutoSize = true;
            this.lblPalvara1.Location = new System.Drawing.Point(160, 64);
            this.lblPalvara1.Name = "lblPalvara1";
            this.lblPalvara1.Size = new System.Drawing.Size(83, 13);
            this.lblPalvara1.TabIndex = 2;
            this.lblPalvara1.Text = "Primeira Palavra";
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(160, 103);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(89, 13);
            this.lblPalavra2.TabIndex = 3;
            this.lblPalavra2.Text = "Segunda Palavra";
            // 
            // btnComparar
            // 
            this.btnComparar.Location = new System.Drawing.Point(125, 159);
            this.btnComparar.Name = "btnComparar";
            this.btnComparar.Size = new System.Drawing.Size(90, 43);
            this.btnComparar.TabIndex = 4;
            this.btnComparar.Text = "COMPARAR PALAVRAS";
            this.btnComparar.UseVisualStyleBackColor = true;
            // 
            // btnInserir
            // 
            this.btnInserir.Location = new System.Drawing.Point(255, 158);
            this.btnInserir.Name = "btnInserir";
            this.btnInserir.Size = new System.Drawing.Size(89, 44);
            this.btnInserir.TabIndex = 5;
            this.btnInserir.Text = "INSERIR PALAVRA";
            this.btnInserir.UseVisualStyleBackColor = true;
            // 
            // btnAsteriscos
            // 
            this.btnAsteriscos.Location = new System.Drawing.Point(371, 158);
            this.btnAsteriscos.Name = "btnAsteriscos";
            this.btnAsteriscos.Size = new System.Drawing.Size(88, 44);
            this.btnAsteriscos.TabIndex = 6;
            this.btnAsteriscos.Text = "INSERIR ASTERISCOS";
            this.btnAsteriscos.UseVisualStyleBackColor = true;
            // 
            // FormEx2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAsteriscos);
            this.Controls.Add(this.btnInserir);
            this.Controls.Add(this.btnComparar);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalvara1);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Name = "FormEx2";
            this.Text = "FormEx2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Label lblPalvara1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.Button btnComparar;
        private System.Windows.Forms.Button btnInserir;
        private System.Windows.Forms.Button btnAsteriscos;
    }
}