﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLado1.Text, out lado1) || lado1 <= 0)
            {
                MessageBox.Show("Lado 1 inválido");
                txtLado1.Focus();
            }
            else if (!Double.TryParse(txtLado2.Text, out lado2) || lado2 <= 0)
            {
                MessageBox.Show("Lado 2 inválido");
                txtLado2.Focus();
            }
            else if (!Double.TryParse(txtLado3.Text, out lado3) || lado3 <= 0)
            {
                MessageBox.Show("Lado 3 inválido");
                txtLado3.Focus();
            }
            else if ((Math.Abs(lado2 - lado3) < lado1) && lado1 < (lado2 + lado3) &&
                     (Math.Abs(lado1 - lado3) < lado2) && lado2 < (lado1 + lado3) &&
                     (Math.Abs(lado1 - lado2) < lado3) && lado3 < (lado1 + lado2) &&
                     lado1 == lado2 && lado2 == lado3 && lado3 == lado1)
            {
                MessageBox.Show("É triângulo equilátero.");
            }
            else if ((Math.Abs(lado2 - lado3) < lado1) && lado1 < (lado2 + lado3) &&
                     (Math.Abs(lado1 - lado3) < lado2) && lado2 < (lado1 + lado3) &&
                     (Math.Abs(lado1 - lado2) < lado3) && lado3 < (lado1 + lado2) &&
                     lado1 == lado2 || lado2 == lado3 || lado3 == lado1)
            {
                MessageBox.Show("É triângulo isósceles.");
            }
            else if ((Math.Abs(lado2 - lado3) < lado1) && lado1 < (lado2 + lado3) &&
                     (Math.Abs(lado1 - lado3) < lado2) && lado2 < (lado1 + lado3) &&
                     (Math.Abs(lado1 - lado2) < lado3) && lado3 < (lado1 + lado2) &&
                     lado1 != lado2 && lado2 != lado3 && lado3 != lado1)
            {
                MessageBox.Show("É triângulo escaleno.");
            }
            else
            {
                MessageBox.Show("Não é um triângulo.");
            }
        }
    }
}
