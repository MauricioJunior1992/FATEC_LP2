﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Double altura = 0, peso = 0, imc = 0;

            if(!Double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Digite um valor válido para peso.");
                return;
            }
            else if (!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Digite um valor válido para peso.");
                return;
            }
            imc = peso / (altura * altura);

            txtIMC.Text = imc.ToString("N2");

            if (imc < 18.5)
            {
                MessageBox.Show("MAGREZA");
            }
            else if (imc <= 24.9)
            {
                MessageBox.Show("NORMAL");
            }
            else if (imc <= 29.9)
            {
                MessageBox.Show("SOBREPESO");
            }
            else if (imc <= 39.9)
            {
                MessageBox.Show("OBESIDADE");
            }
            else
            {
                MessageBox.Show("OBESIDADE GRAVE");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtIMC.Text = "";
            txtPeso.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
