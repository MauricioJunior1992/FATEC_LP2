namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Valor de raio inv�lido.");
                //txtRaio.Focus();
            }
            else if (raio <= 0)
            {
                MessageBox.Show("Raio deve ser maior que zero.");
                //txtRaio.Focus();
            }
        }

        private void txtAltura_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inv�lida.");
                //e.Cancel = true;
            }
            else if (altura <= 0)
            {
                MessageBox.Show("Altura deve ser maior que zero.");
                //e.Cancel = true;
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) ||
                !Double.TryParse(txtAltura.Text, out altura) ||
                raio<=0 || altura <= 0)
                {
                MessageBox.Show("N�meros inv�lidos");
                txtRaio.Focus();
                }
            else
            {
                resultado = Math.PI * Math.Pow(raio, 2) * altura;
                txtResultado.Text = resultado.ToString("N2");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = " ";
            txtAltura.Text = string.Empty;
            txtResultado.Clear();
        }
    }
}
