﻿namespace PVolume
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblRaio = new Label();
            lblAltura = new Label();
            lblResultado = new Label();
            txtRaio = new TextBox();
            txtAltura = new TextBox();
            txtResultado = new TextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblRaio
            // 
            lblRaio.AutoSize = true;
            lblRaio.Location = new Point(100, 54);
            lblRaio.Name = "lblRaio";
            lblRaio.Size = new Size(34, 15);
            lblRaio.TabIndex = 0;
            lblRaio.Text = "RAIO";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(85, 111);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(49, 15);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "ALTURA";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(65, 165);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(69, 15);
            lblResultado.TabIndex = 2;
            lblResultado.Text = "RESULTADO";
            // 
            // txtRaio
            // 
            txtRaio.Location = new Point(154, 51);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(133, 23);
            txtRaio.TabIndex = 0;
            txtRaio.Validated += txtRaio_Validated;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(154, 108);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(133, 23);
            txtAltura.TabIndex = 1;
            txtAltura.Validating += txtAltura_Validating;
            // 
            // txtResultado
            // 
            txtResultado.Enabled = false;
            txtResultado.Location = new Point(154, 162);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(133, 23);
            txtResultado.TabIndex = 2;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.PaleGreen;
            btnCalcular.Location = new Point(85, 242);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(117, 52);
            btnCalcular.TabIndex = 3;
            btnCalcular.Text = "CALCULAR";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(251, 242);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(117, 52);
            btnLimpar.TabIndex = 4;
            btnLimpar.Text = "LIMPAR";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.BackColor = Color.FromArgb(255, 192, 192);
            btnSair.Location = new Point(421, 242);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(117, 52);
            btnSair.TabIndex = 5;
            btnSair.Text = "SAIR";
            btnSair.UseVisualStyleBackColor = false;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtResultado);
            Controls.Add(txtAltura);
            Controls.Add(txtRaio);
            Controls.Add(lblResultado);
            Controls.Add(lblAltura);
            Controls.Add(lblRaio);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblRaio;
        private Label lblAltura;
        private Label lblResultado;
        private TextBox txtRaio;
        private TextBox txtAltura;
        private TextBox txtResultado;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
    }
}
