﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class FormEx4 : Form
    {
        public FormEx4()
        {
            InitializeComponent();
        }

        private void btnCalcularSalBrut_Click(object sender, EventArgs e)
        {
            double A = 0, B = 0, C = 0, D = 0;
            double producao = 0, salBruto = 0, gratificacao = 0;
            if (!Double.TryParse(txtProd.Text, out producao))
            {
                MessageBox.Show("Digite um valor válido para produção");
                return;
            }
            else if (!Double.TryParse(txtSalario.Text, out A))
            {
                MessageBox.Show("Digite um valor válido para salário.");
                return;
            }
            else if (!Double.TryParse(txtGratif.Text, out gratificacao))
            {
                MessageBox.Show("Digite um valor válido para gratificação.");
                return;
            }
            else if (producao >= 150)
            {
                D = 1; C = 1; B = 1;
            }
            else if (producao >= 120)
            {
                C = 1; B = 1;
            }
            else if (producao >= 100)
            {
                B = 1;
            }
            salBruto = A + A * ((0.05 * B) + (0.1 * C) + (0.1 * D)) + gratificacao;

            if (salBruto > 7000 && (producao < 150 || gratificacao == 0))
            {
                salBruto = 7000;
            }
            MessageBox.Show("NOME: " + txtNome.Text + "\nMATRÍCULA: " + txtMatric.Text +
                   "\nPRODUÇÃO: " + txtProd.Text + "\nSALÁRIO: R$" + A.ToString("N2") +
                   "\nGRATIFICAÇÃO: R$" + gratificacao.ToString("N2") + "\n\nSALÁRIO BRUTO: R$" +
                   salBruto.ToString("N2"));
        }
    }
}
