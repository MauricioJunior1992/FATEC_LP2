﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx1>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["FormEx1"].BringToFront();
            }
            else
            {
                FormEx1 obj1 = new FormEx1();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx2>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["FormEx2"].BringToFront();
            }
            else
            {
                FormEx2 obj1 = new FormEx2();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx3>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["FormEx3"].BringToFront();
            }
            else
            {
                FormEx3 obj1 = new FormEx3();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["FormEx4"].BringToFront();
            }
            else
            {
                FormEx4 obj1 = new FormEx4();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
