﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class FormEx2 : Form
    {
        public FormEx2()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            int num;
            double h=0;
            if (!int.TryParse(txtNum.Text, out num))
            {
                MessageBox.Show("Digite um número válido.");
                txtNum.Focus();
            }
            else if (num == 0)
            {
                MessageBox.Show("Digite um número maior que ZERO.");
                txtNum.Focus();
            }
            else
            {
                for (double i = 1; i <= num; i++)
                {
                    h += (1/i);
                }
                MessageBox.Show("O resultado é " + h + " .");
            }
        }
    }
}
