﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class FormEx3 : Form
    {
        public FormEx3()
        {
            InitializeComponent();
        }

        private void btnPalíndromo_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text;
            char[] fraseArray = frase.ToCharArray();
            Array.Reverse(fraseArray);
            string fraseInvertida = new string(fraseArray);

            
        
            if(frase == fraseInvertida)
            {
                MessageBox.Show("A frase é: " + frase + ".\nA frase invertida é: " + fraseInvertida + ".\n\nÉ polídromo!");
            }
            else
            {
                MessageBox.Show("A frase é: " + frase + ".\nA frase invertida é: " + fraseInvertida + ".\n\nNão é políndromo!");
            }

        }
    }
}
