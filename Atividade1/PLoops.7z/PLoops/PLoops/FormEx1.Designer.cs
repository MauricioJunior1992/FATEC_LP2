﻿namespace PLoops
{
    partial class FormEx1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEspBranco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnParDeLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(226, 71);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(321, 137);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            this.rchtxtFrase.TextChanged += new System.EventHandler(this.rchtxtFrase_TextChanged);
            // 
            // btnEspBranco
            // 
            this.btnEspBranco.Location = new System.Drawing.Point(147, 251);
            this.btnEspBranco.Name = "btnEspBranco";
            this.btnEspBranco.Size = new System.Drawing.Size(119, 76);
            this.btnEspBranco.TabIndex = 1;
            this.btnEspBranco.Text = "Nº de Espaços em Branco";
            this.btnEspBranco.UseVisualStyleBackColor = true;
            this.btnEspBranco.Click += new System.EventHandler(this.btnEspBranco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(328, 250);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(127, 77);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Nº de Letras R";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnParDeLetras
            // 
            this.btnParDeLetras.Location = new System.Drawing.Point(512, 250);
            this.btnParDeLetras.Name = "btnParDeLetras";
            this.btnParDeLetras.Size = new System.Drawing.Size(117, 77);
            this.btnParDeLetras.TabIndex = 3;
            this.btnParDeLetras.Text = "Nº de Par de Letras";
            this.btnParDeLetras.UseVisualStyleBackColor = true;
            this.btnParDeLetras.Click += new System.EventHandler(this.btnParDeLetras_Click);
            // 
            // FormEx1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnParDeLetras);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspBranco);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "FormEx1";
            this.Text = "FormEx1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnEspBranco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnParDeLetras;
    }
}