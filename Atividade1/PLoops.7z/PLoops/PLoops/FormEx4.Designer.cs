﻿namespace PLoops
{
    partial class FormEx4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatrícula = new System.Windows.Forms.Label();
            this.lblProdução = new System.Windows.Forms.Label();
            this.lblSalário = new System.Windows.Forms.Label();
            this.lblGratificação = new System.Windows.Forms.Label();
            this.txtProd = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtGratif = new System.Windows.Forms.TextBox();
            this.txtMatric = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.btnCalcularSalBrut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(145, 82);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(39, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "NOME";
            // 
            // lblMatrícula
            // 
            this.lblMatrícula.AutoSize = true;
            this.lblMatrícula.Location = new System.Drawing.Point(115, 108);
            this.lblMatrícula.Name = "lblMatrícula";
            this.lblMatrícula.Size = new System.Drawing.Size(69, 13);
            this.lblMatrícula.TabIndex = 1;
            this.lblMatrícula.Text = "MATRÍCULA";
            // 
            // lblProdução
            // 
            this.lblProdução.AutoSize = true;
            this.lblProdução.Location = new System.Drawing.Point(116, 134);
            this.lblProdução.Name = "lblProdução";
            this.lblProdução.Size = new System.Drawing.Size(68, 13);
            this.lblProdução.TabIndex = 2;
            this.lblProdução.Text = "PRODUÇÃO";
            // 
            // lblSalário
            // 
            this.lblSalário.AutoSize = true;
            this.lblSalário.Location = new System.Drawing.Point(131, 159);
            this.lblSalário.Name = "lblSalário";
            this.lblSalário.Size = new System.Drawing.Size(53, 13);
            this.lblSalário.TabIndex = 3;
            this.lblSalário.Text = "SALÁRIO";
            // 
            // lblGratificação
            // 
            this.lblGratificação.AutoSize = true;
            this.lblGratificação.Location = new System.Drawing.Point(99, 184);
            this.lblGratificação.Name = "lblGratificação";
            this.lblGratificação.Size = new System.Drawing.Size(85, 13);
            this.lblGratificação.TabIndex = 4;
            this.lblGratificação.Text = "GRATIFICAÇÃO";
            // 
            // txtProd
            // 
            this.txtProd.Location = new System.Drawing.Point(190, 131);
            this.txtProd.Name = "txtProd";
            this.txtProd.Size = new System.Drawing.Size(100, 20);
            this.txtProd.TabIndex = 3;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(190, 156);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(100, 20);
            this.txtSalario.TabIndex = 4;
            // 
            // txtGratif
            // 
            this.txtGratif.Location = new System.Drawing.Point(190, 181);
            this.txtGratif.Name = "txtGratif";
            this.txtGratif.Size = new System.Drawing.Size(100, 20);
            this.txtGratif.TabIndex = 5;
            // 
            // txtMatric
            // 
            this.txtMatric.Location = new System.Drawing.Point(190, 105);
            this.txtMatric.Name = "txtMatric";
            this.txtMatric.Size = new System.Drawing.Size(100, 20);
            this.txtMatric.TabIndex = 2;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(190, 79);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 1;
            // 
            // btnCalcularSalBrut
            // 
            this.btnCalcularSalBrut.Location = new System.Drawing.Point(190, 216);
            this.btnCalcularSalBrut.Name = "btnCalcularSalBrut";
            this.btnCalcularSalBrut.Size = new System.Drawing.Size(152, 43);
            this.btnCalcularSalBrut.TabIndex = 6;
            this.btnCalcularSalBrut.Text = "CALCULAR SALÁRIO BRUTO";
            this.btnCalcularSalBrut.UseVisualStyleBackColor = true;
            this.btnCalcularSalBrut.Click += new System.EventHandler(this.btnCalcularSalBrut_Click);
            // 
            // FormEx4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcularSalBrut);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatric);
            this.Controls.Add(this.txtGratif);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtProd);
            this.Controls.Add(this.lblGratificação);
            this.Controls.Add(this.lblSalário);
            this.Controls.Add(this.lblProdução);
            this.Controls.Add(this.lblMatrícula);
            this.Controls.Add(this.lblNome);
            this.Name = "FormEx4";
            this.Text = "FormEx4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatrícula;
        private System.Windows.Forms.Label lblProdução;
        private System.Windows.Forms.Label lblSalário;
        private System.Windows.Forms.Label lblGratificação;
        private System.Windows.Forms.TextBox txtProd;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtGratif;
        private System.Windows.Forms.TextBox txtMatric;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnCalcularSalBrut;
    }
}