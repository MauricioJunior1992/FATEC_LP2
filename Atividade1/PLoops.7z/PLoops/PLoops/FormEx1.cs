﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class FormEx1 : Form
    {
        public FormEx1()
        {
            InitializeComponent();
        }

        private void rchtxtFrase_TextChanged(object sender, EventArgs e)
        {
            rchtxtFrase.MaxLength = 100;
        }

        private void btnEspBranco_Click(object sender, EventArgs e)
        {
            int qtdEspBranco = 0;
            for (int i = 0; i < rchtxtFrase.TextLength; i++)
            {
               if (rchtxtFrase.Text[i] == ' ')
                {
                    qtdEspBranco++;
                }
            }
            MessageBox.Show("Existe(m) " + qtdEspBranco.ToString() + " espaço(s) em branco.");
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int qtdR = 0;
            for (int i = 0; i < rchtxtFrase.TextLength; i++)
            {
                if (rchtxtFrase.Text[i] == 'r' || rchtxtFrase.Text[i] == 'R')
                {
                    qtdR++;
                }
            }
            MessageBox.Show("Existe(m) " + qtdR.ToString() + " letra(s) 'R'.");

        }

        private void btnParDeLetras_Click(object sender, EventArgs e)
        {
            int qtdIguais = 0;
            for (int i = 1; i < rchtxtFrase.TextLength; i++)
            {
                if (rchtxtFrase.Text[i] == rchtxtFrase.Text[i-1])
                {
                    qtdIguais++;
                }
            }
            MessageBox.Show("Existe(m) " + qtdIguais.ToString() + " letra(s) iguais repetidas.");

        }
    }
}
